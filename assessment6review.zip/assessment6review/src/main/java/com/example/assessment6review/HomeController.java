package com.example.assessment6review;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {
	@Autowired
	private BusinessRepository br;
	
	@RequestMapping("/")
	public ModelAndView indexPage() {
		List<Business> businesses = br.findAll();
		return new ModelAndView("index", "businessList", businesses);
	}
	
	@RequestMapping("create-business")
	public ModelAndView addBusiness(Business b) {
		br.save(b);
		return new ModelAndView("redirect:/");
	}
	
	@RequestMapping("delete")
	public ModelAndView deleteBusiness(Business b) {
		br.deleteById(b.getId());
		return new ModelAndView("redirect:/");
	}

}
