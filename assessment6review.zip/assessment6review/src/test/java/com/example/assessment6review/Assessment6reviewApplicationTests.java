package com.example.assessment6review;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assessment6reviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
